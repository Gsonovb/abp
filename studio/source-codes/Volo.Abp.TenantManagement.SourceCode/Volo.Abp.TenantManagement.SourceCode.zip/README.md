# abp-tenantmanagement
Tenant management module for ABP framework.
