﻿using Volo.Abp.Localization;

namespace Volo.Abp.TenantManagement.Localization
{
    [LocalizationResourceName("AbpTenantManagement")]
    public class AbpTenantManagementResource
    {
        
    }
}
