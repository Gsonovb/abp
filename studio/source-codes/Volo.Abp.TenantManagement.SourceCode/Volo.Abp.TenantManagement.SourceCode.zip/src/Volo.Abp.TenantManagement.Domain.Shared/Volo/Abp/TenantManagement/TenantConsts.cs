﻿namespace Volo.Abp.TenantManagement
{
    public static class TenantConsts
    {
        /// <summary>
        /// Default value: 64
        /// </summary>
        public static int MaxNameLength { get; set; } = 64;
    }
}
