﻿namespace Volo.Abp.BlobStoring.Database;

public static class DatabaseContainerConsts
{
    /// <summary>
    /// Default value: 128.
    /// </summary>
    public static int MaxNameLength { get; set; } = 128;
}
