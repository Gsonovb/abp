﻿namespace Volo.Abp.BlobStoring.Database;

public static class BlobStoringDatabaseErrorCodes
{
    //Add your business exception error codes here...
}
